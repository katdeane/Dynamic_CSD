function teg_RM_plot(toplot)

